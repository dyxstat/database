#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 11:39:37 2024

@author: macbookair
"""
from tqdm import tqdm
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold,RandomizedSearchCV
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score, make_scorer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn.svm import SVC
from lightgbm import LGBMClassifier
import scipy.stats
import warnings
warnings.filterwarnings("ignore")
# Assuming TSD_selected and y are already loaded as DataFrame and target array
TSD_3D=np.load("/Users/macbookair/python/Allergy/TSD_3D.npy")
TSD=pd.read_csv("/Users/macbookair/python/Allergy/TSD.csv")
TSD_long=pd.read_csv("/Users/macbookair/python/Allergy/TSD_long.csv")
y = np.concatenate([np.zeros(169), np.ones(42)])
TSD_selected=pd.read_csv("TSD_selected.csv")
# Clean the feature names to remove special JSON characters
TSD_selected.columns = [col.replace('{', '').replace('}', '').replace(':', '').replace(']', '').replace('[', '') for col in TSD_selected.columns]

"""
Integrate hyperparameter tuning with model evaluation, repeating the process
to calculate mean and 95% CI for performance metrics.
"""

# Define models and their hyperparameter search spaces
model_params = {
    "Logistic Regression": {
        "model": LogisticRegression(),
        "params": {
            "C": np.logspace(-4, 4, 20),
            "solver": ["liblinear", "lbfgs"]
        }
    },
    "Random Forest": {
        "model": RandomForestClassifier(),
        "params": {
            "n_estimators": [10, 50, 100, 200,400],
            "max_depth": [None, 10, 20, 30],
            "min_samples_split": [2, 5, 10],
            "min_samples_leaf": [1, 2, 4]
        }
    },
    "SVM": {
        "model": SVC(probability=True),
        "params": {
            "C": np.logspace(-4, 4, 10),
            "kernel": ["poly", "rbf", "sigmoid"],
            "gamma": ["scale", "auto"]
        }
    },
    "XGBoost": {
        "model": XGBClassifier(use_label_encoder=False, eval_metric='logloss'),
        "params": {
            "n_estimators": [50, 100, 200,400],
            "learning_rate": np.logspace(-3, 0, 10),
            "max_depth": [3, 6, 9],
            "min_child_weight": [1, 5, 10],
        }
    }
}

n_repeats = 2

results = {name: {'AUC': [], 'PRCauc': []} for name in model_params}

for _ in tqdm(range(n_repeats), desc="Overall Progress"):
    X_train, X_test, y_train, y_test = train_test_split(TSD_selected, y, test_size=0.3, stratify=y)
    
    for name, mp in model_params.items():
        cv = StratifiedKFold(n_splits=5)
        search = RandomizedSearchCV(mp['model'], mp['params'], n_iter=10, scoring='roc_auc', cv=cv, random_state=42)
        search.fit(X_train, y_train)
        best_model = search.best_estimator_
        
        predictions = best_model.predict_proba(X_test)[:, 1]
        auc_score = roc_auc_score(y_test, predictions)
        prc_score = average_precision_score(y_test, predictions)
        
        results[name]['AUC'].append(auc_score)
        results[name]['PRCauc'].append(prc_score)

final_results = {}
for model_name, metrics in results.items():
    final_results[model_name] = {}
    for metric, values in metrics.items():
        mean_value = np.mean(values)
        ci_low, ci_high = scipy.stats.t.interval(0.95, len(values)-1, loc=mean_value, scale=scipy.stats.sem(values))
        final_results[model_name][metric] = {"mean": mean_value, "95% CI": (ci_low, ci_high)}

data = []
for model_name, metrics in final_results.items():
    for metric, result in metrics.items():
        data.append({
            'Model': model_name,
            'Metric': metric,
            'Mean': result['mean'],
            '95% CI Lower': result['95% CI'][0],
            '95% CI Upper': result['95% CI'][1]
        })
results_df = pd.DataFrame(data)
print(results_df)